package com.b2110941.CartService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
