package com.b2110941.ChatService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
