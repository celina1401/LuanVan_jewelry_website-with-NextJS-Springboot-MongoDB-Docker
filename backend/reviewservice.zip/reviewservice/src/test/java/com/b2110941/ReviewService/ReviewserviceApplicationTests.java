package com.b2110941.ReviewService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
